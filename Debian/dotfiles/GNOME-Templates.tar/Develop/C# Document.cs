
using System;

namespace 
{
	
	public class New C# Document
	{
		
		public New C# Document()
		{
		}
	}
	
}
